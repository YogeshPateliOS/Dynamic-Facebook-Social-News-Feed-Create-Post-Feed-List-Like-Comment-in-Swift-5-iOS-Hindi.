//
//  SocialFeedCell.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/29/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit
import Lightbox

class SocialFeedCell: UITableViewCell {

    @IBOutlet weak var btnComment: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnShare: UIButton!
    @IBOutlet weak var collectionFeedImgVIew: UICollectionView!
    var modelSocialFeed: SocialFeedModel?{
         didSet{
             updateData()
         }
     }
    
    override func awakeFromNib() {
        super.awakeFromNib()
          collectionFeedImgVIew.register(UINib(nibName: "SocialFeedImageCell", bundle: nil), forCellWithReuseIdentifier: "SocialFeedImageCell")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func updateData(){
        lblTitle.text = modelSocialFeed?.title
        if modelSocialFeed?.media.count ?? 0 > 0{
            collectionFeedImgVIew.isHidden = false
            collectionFeedImgVIew.dataSource = self
            collectionFeedImgVIew.delegate = self
            collectionFeedImgVIew.reloadData()
        }else{
            collectionFeedImgVIew.isHidden = true
        }
    }
    
    func configurationOfLightbox() -> [LightboxImage]{
        var lightboxImages = [LightboxImage]()
        for media in modelSocialFeed!.media{
            let lightBox  = LightboxImage(image: media.thumbnail, text: "", videoURL: URL(string: media.url))
            lightboxImages.append(lightBox)
        }
        return lightboxImages
    }
}


extension SocialFeedCell: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        (modelSocialFeed?.media.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SocialFeedImageCell", for: indexPath) as? SocialFeedImageCell else { return UICollectionViewCell() }
        cell.feedImg.image = modelSocialFeed?.media[indexPath.row].thumbnail
        return cell
    }
}

extension SocialFeedCell: UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let lightController = LightboxController(images: configurationOfLightbox(), startIndex: indexPath.row)
        lightController.modalPresentationStyle = .fullScreen
        UIApplication.getTopViewController()?.present(lightController, animated: true)
    }
}

extension SocialFeedCell: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: collectionView.bounds.width/3, height: collectionView.bounds.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}
