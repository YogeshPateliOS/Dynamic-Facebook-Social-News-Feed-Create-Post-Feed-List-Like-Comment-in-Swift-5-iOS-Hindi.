//
//  SocialFeedImageCell.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/28/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

class SocialFeedImageCell: UICollectionViewCell {

    @IBOutlet weak var feedImg: UIImageView!
 
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
