//
//  SocialFeedModel.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/28/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

struct SocialFeedModel {
    var id = ""
    var title = ""
    var media = [MediaModel]()
}

class SocialFeedDataModel{
    static let shareInstance = SocialFeedDataModel()
    var arrSocialFeed = [SocialFeedModel]()
}

struct MediaModel{
    var mediaType: MediaType?
    var thumbnail = UIImage()
    var url = ""
}

enum MediaType{
    case photo, video
}


struct CommentModel{
    var socialFeedID = ""
    var commentID = ""
    var title = ""
}

class CommentDataModel{
    static let shareInstance = CommentDataModel()
    var arrComments = [CommentModel]()
}
