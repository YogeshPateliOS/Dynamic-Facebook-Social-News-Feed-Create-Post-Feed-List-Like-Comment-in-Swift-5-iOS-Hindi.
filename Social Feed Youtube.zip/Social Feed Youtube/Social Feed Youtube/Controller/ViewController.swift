//
//  ViewController.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/28/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tblSocialFeed: UITableView!
    let socialFeedInstance = SocialFeedDataModel.shareInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblSocialFeed.register(UINib(nibName: "SocialFeedCell", bundle: nil), forCellReuseIdentifier: "SocialFeedCell")
    }
    
    @IBAction func btnAddFeedTapped(_ sender: UIBarButtonItem) {
        let createPostVC = CreatePostViewController.shareInstance()
        createPostVC.delegate = self
        self.navigationController?.pushViewController(createPostVC, animated: true)
    }
    
    @objc
    func btnLikeTapped(sender: UIButton){
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                sender.transform = CGAffineTransform(scaleX: 1.6, y: 1.6)
                // sender.alpha = 0.0
            }) { finished in
                // sender.alpha = 1.0
                UIView.animate(withDuration: 0.3) {
                    sender.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                }
            }
        }
    }
    
    @objc
    func btnCommentTapped(sender: UIButton){
        let commentVC = CommentViewController.shareInstance()
        commentVC.modelSocialFeed = socialFeedInstance.arrSocialFeed[sender.tag]
        self.navigationController?.pushViewController(commentVC, animated: true)
    }
}

extension ViewController: SocialFeedRefresh{
    func refreshData() {
        tblSocialFeed.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        socialFeedInstance.arrSocialFeed.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SocialFeedCell", for: indexPath) as? SocialFeedCell else { return UITableViewCell() }
        cell.modelSocialFeed = socialFeedInstance.arrSocialFeed[indexPath.row]
        cell.btnLike.tag = indexPath.row
        cell.btnLike.addTarget(self, action: #selector(btnLikeTapped(sender:)), for: .touchUpInside)
        cell.btnComment.tag = indexPath.row
        cell.btnComment.addTarget(self, action: #selector(btnCommentTapped(sender:)), for: .touchUpInside)
        return cell
    }

}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
}
