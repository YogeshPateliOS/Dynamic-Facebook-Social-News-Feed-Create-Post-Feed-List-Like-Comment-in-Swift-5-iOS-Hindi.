//
//  CommentViewController.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/29/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

class CommentViewController: UIViewController {

    @IBOutlet weak var txtComment: UITextField!
    @IBOutlet weak var tblCommentView: UITableView!
    let modelComment = CommentDataModel.shareInstance
    var modelSocialFeed = SocialFeedModel()
    var arrComments = [CommentModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       arrComments = modelComment.arrComments.filter{ $0.socialFeedID == modelSocialFeed.id }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        txtComment.becomeFirstResponder()
    }
    
    @IBAction func btnSendTapped(_ sender: UIButton) {
        let modelData = CommentModel(socialFeedID: modelSocialFeed.id, commentID: "\(modelComment.arrComments.count + 1)", title: txtComment.text!)
        modelComment.arrComments.append(modelData)
        arrComments.append(modelData)
        tblCommentView.reloadData()
        txtComment.resignFirstResponder()
    }
    
}

extension CommentViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrComments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arrComments[indexPath.row].title
        return cell
    }
}


extension CommentViewController{
    static func shareInstance() -> CommentViewController{
        CommentViewController.instantiateFromStoryboard()
    }
}
