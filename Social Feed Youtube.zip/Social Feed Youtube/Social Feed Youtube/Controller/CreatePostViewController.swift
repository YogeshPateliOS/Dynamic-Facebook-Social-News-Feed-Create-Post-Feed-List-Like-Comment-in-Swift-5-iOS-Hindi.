//
//  CreatePostViewController.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/28/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit
import YPImagePicker
import AVKit

protocol SocialFeedRefresh: class {
    func refreshData()
}

class CreatePostViewController: UIViewController {

    var selectedItems = [YPMediaItem]()
    @IBOutlet weak var txtCreatePostView: UITextView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var btnPhotoVideo: UIButton!
    var modelSocialFeed = SocialFeedModel()
    weak var delegate: SocialFeedRefresh?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.isHidden = true
        collectionView.register(UINib(nibName: "SocialFeedImageCell", bundle: nil), forCellWithReuseIdentifier: "SocialFeedImageCell")
        
    }
    
    @IBAction func btnPhotoVideoTapped(sender: UIButton){
        showPicker()
    }
    
    @IBAction func btnDoneTapped(sender: UIBarButtonItem){
        guard let txt = txtCreatePostView.text else { return }
        modelSocialFeed.title = txt
        modelSocialFeed.id = "\(SocialFeedDataModel.shareInstance.arrSocialFeed.count + 1)"
        print(modelSocialFeed)
        SocialFeedDataModel.shareInstance.arrSocialFeed.append(modelSocialFeed)
        delegate?.refreshData()
        self.navigationController?.popViewController(animated: true)
    }

}

// YPImagePickerController Configuration
extension CreatePostViewController{
    func showPicker() {
            
            var config = YPImagePickerConfiguration()
            config.library.mediaType = .photoAndVideo
            config.shouldSaveNewPicturesToAlbum = false
            config.video.compression = AVAssetExportPresetMediumQuality
            config.startOnScreen = .library
            config.screens = [.library, .photo, .video]
            config.video.libraryTimeLimit = 500.0
            config.wordings.libraryTitle = "Gallery"
            config.hidesStatusBar = false
            config.hidesBottomBar = false
            config.maxCameraZoomFactor = 2.0
            config.library.maxNumberOfItems = 5
            config.gallery.hidesRemoveButton = false
            config.library.preselectedItems = selectedItems
            let picker = YPImagePicker(configuration: config)

            picker.didFinishPicking { [unowned picker] items, cancelled in
                
                if cancelled {
                    print("Picker was canceled")
                    picker.dismiss(animated: true, completion: nil)
                    return
                }
                _ = items.map { print("🧀 \($0)") }
                
                self.selectedItems = items
                for item in items{
                    switch item {
                    case .photo(let photo):
                        self.modelSocialFeed.media.append(MediaModel(mediaType: .photo, thumbnail: photo.image, url: ""))
                    case .video(let video):
                        self.modelSocialFeed.media.append(MediaModel(mediaType: .video, thumbnail: video.thumbnail, url: "\(video.url)"))
                    }
                }
                picker.dismiss(animated: true) {
                    self.collectionView.isHidden = false
                    self.collectionView.reloadData()
                }
            }
                
            present(picker, animated: true, completion: nil)
        }
}


extension CreatePostViewController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        modelSocialFeed.media.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SocialFeedImageCell", for: indexPath) as? SocialFeedImageCell else { return UICollectionViewCell() }
        cell.feedImg.image = modelSocialFeed.media[indexPath.row].thumbnail
        return cell
    }
}

extension CreatePostViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: collectionView.bounds.width/3, height: collectionView.bounds.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}

extension CreatePostViewController{
   static func shareInstance() -> CreatePostViewController{
        return CreatePostViewController.instantiateFromStoryboard()
    }
}
