//
//  UIViewController + Extension.swift
//  Social Feed Youtube
//
//  Created by Yogesh Patel on 3/29/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

extension UIViewController{

    class func instantiateFromStoryboard(_ name: String = "Main") -> Self
    {
        return instantiateFromStoryboardHelper(name)
    }

    fileprivate class func instantiateFromStoryboardHelper<T>(_ name: String) -> T
    {
        let storyboard = UIStoryboard(name: name, bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "\(Self.self)") as! T
        return controller
    }

    
    
    
    
    
    func popupAlert(title: String, message: String, alertControllerStyle: UIAlertController.Style, actionTitles: [String], actionStyles: [UIAlertAction.Style], alertActions: [((UIAlertAction) -> Void)]){
        let alert = UIAlertController(title: title, message: message, preferredStyle: alertControllerStyle)
        for (index, title) in actionTitles.enumerated(){
            let action = UIAlertAction(title: title, style: actionStyles[index], handler: alertActions[index])
            alert.addAction(action)
        }
        self.present(alert, animated: true, completion: nil)
    }

    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

}
